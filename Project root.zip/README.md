# cat_toilet_alert
Get alerted when your cat climbs the toilet using computer vision [YOLO v3]

video example:
https://drive.google.com/file/d/1lw1XBSVwmFtjpS_IZsI4LXPFwvL-htnS/view?usp=sharing

using:
replace file path on the notebook file
